# Core domain (QR, billing)
