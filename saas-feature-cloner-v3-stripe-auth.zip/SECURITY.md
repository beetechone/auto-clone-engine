Follow OWASP ASVS L2. Use coordinated disclosure.
