# Test Plan
- Unit: encoders, controllers, auth
- Contract: OpenAPI conformance
- E2E: guest generate; auth save; paid plan limits
- Perf: smoke; Lighthouse CI
