# Architecture
- FE: Next.js + Tailwind + shadcn
- API: FastAPI; Postgres; Redis; S3; Stripe; Auth0 JWT
- Observability: structured logs; health; metrics
