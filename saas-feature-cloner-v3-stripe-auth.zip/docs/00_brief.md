# Project Brief — QR Generator Clone
Goal: replicate features with original branding.
