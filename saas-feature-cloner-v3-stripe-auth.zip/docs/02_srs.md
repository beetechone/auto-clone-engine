# SRS
- MUST: QR URL/Text/Wi-Fi/vCard/Event; PNG/SVG; account; save; basic analytics
- SHOULD: Templates; PDF; folders; Stripe billing
- COULD: Teams; custom domains; shortlinks
- NFR: Perf TTI<2s P95; TTFB<500ms; WCAG AA; OWASP ASVS L2
