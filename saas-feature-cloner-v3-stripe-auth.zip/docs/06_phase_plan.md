# Phase Plan
- P0: Discovery + Specs
- P1: Backend MVP (QR + Auth + Plans)
- P2: Editor + Export PNG/SVG
- P3: Library + Dashboard
- P4: Templates + Admin
- P5: Billing + Limits
- P6: Analytics + Hardening
