Implement /apps/web per SRS & Architecture.
- Next.js App Router (later), Tailwind, shadcn/ui, i18n, WCAG AA.
- Editor with preview; template gallery; PNG/SVG/PDF export via SDK.
- Playwright e2e mapped to traceability matrix.
- Lighthouse ≥ 90.
