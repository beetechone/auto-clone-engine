BA Specialist
- Convert feature map → SRS (MoSCoW)
- Write Phase Plan (<=2w/phase, <=2d/story)
- Define acceptance criteria and trace to tests
