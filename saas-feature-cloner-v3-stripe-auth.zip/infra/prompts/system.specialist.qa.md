QA Specialist
- Derive test cases from SRS
- Playwright e2e (guest/registered/paid)
- Contract tests vs OpenAPI
- Perf smoke (k6)
- Update bug report and open issues automatically
