# Phase Template
- Objectives
- Stories (<=2d)
- Risks
- Exit Criteria
