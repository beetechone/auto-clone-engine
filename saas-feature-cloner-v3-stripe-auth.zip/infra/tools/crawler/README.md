Playwright crawler to map headings/forms/links.
