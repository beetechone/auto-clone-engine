console.log('Admin scaffold placeholder.');
